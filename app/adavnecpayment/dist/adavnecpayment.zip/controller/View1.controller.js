sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("adavnecpayment.controller.View1",{onInit:function(){}})});
//# sourceMappingURL=View1.controller.js.map